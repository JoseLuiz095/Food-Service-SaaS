import { ArrowRight, BarChart3, Check, LockKeyhole, MessageCircle, ShieldCheck, ShoppingBag, Sparkles, Store, Wallet } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { ProtectedContactButton } from '../../components/ProtectedContactButton';
import { LoadingState } from '../../components/ui/AsyncState';
import { loadPublicLanding, type PublicLanding } from '../../services/landingApi';
import { currency } from '../../utils/format';

const featureLabels:Record<string,string>={
  storefront:'Cardápio digital',orders:'Pedidos online',whatsapp:'WhatsApp',analytics:'Analytics comercial',
  finance:'Financeiro gerencial',financial_documents:'Leitura de documentos',custom_banner:'Banner personalizado',
  multiple_images:'Mais fotos por produto',delivery:'Delivery e retirada',
};

const fallback:PublicLanding={
  stores:[],demoStoreSlug:'central-food-demo',demoEnabled:true,demoDurationDays:30,contactProtected:true,
  plans:[
    {id:'essential',code:'ESSENTIAL',name:'Essencial',monthlyPrice:49.9,featureCodes:['storefront','orders','whatsapp','delivery']},
    {id:'starter',code:'STARTER',name:'Starter',monthlyPrice:79.9,featureCodes:['storefront','orders','whatsapp','delivery','analytics','multiple_images']},
    {id:'professional',code:'PROFESSIONAL',name:'Profissional',monthlyPrice:119.9,featureCodes:['storefront','orders','whatsapp','delivery','analytics','finance','financial_documents','custom_banner']},
  ],
};

export default function Landing(){
  const[data,setData]=useState<PublicLanding|null>(null);
  useEffect(()=>{void loadPublicLanding().then(setData).catch(()=>setData(fallback))},[]);
  const view=data||fallback;
  const demo=useMemo(()=>view.stores.find((store)=>store.slug===view.demoStoreSlug)||view.stores[0],[view]);
  const demoHref=`/${encodeURIComponent(view.demoStoreSlug)}`;
  const trialDays=view.demoEnabled?view.demoDurationDays:30;
  if(!data)return <div className="landing-loading"><LoadingState label="Preparando apresentação FoodWeb..."/></div>;

  return <div className="food-sales-page food-sales-page-v43 food-sales-page-v44">
    <header className="sales-nav sales-nav-v44"><div className="sales-shell">
      <a className="sales-brand" href="/"><span className="foodweb-brand-mark">FW</span><strong>FoodWeb</strong></a>
      <nav><a href="#recursos">Recursos</a><a href="#demonstracao">Demonstração</a><a href="#lojas">Lojas</a><a href="#planos">Planos</a></nav>
      <div className="sales-nav-actions"><a href="/admin/login">Entrar</a><ProtectedContactButton className="sales-nav-primary" intent="trial" label={`Testar por ${trialDays} dias`}/></div>
    </div></header>

    <main>
      <section className="sales-hero sales-hero-v43 sales-hero-v44"><div className="sales-shell sales-hero-grid-v43">
        <div className="sales-hero-copy"><span className="sales-kicker"><Sparkles size={16}/> Plataforma completa para delivery</span><h1>Seu cardápio profissional, seus pedidos e sua gestão <em>em um só lugar.</em></h1><p>Venda pela web e WhatsApp com uma experiência moderna para o cliente e ferramentas práticas para o lojista acompanhar pedidos, analytics e financeiro.</p>
          <div className="sales-hero-actions"><ProtectedContactButton className="sales-cta-primary sales-cta-trial" intent="trial"><MessageCircle size={18}/>Testar o Profissional por {trialDays} dias</ProtectedContactButton><a className="sales-cta-secondary" href={demoHref}>Ver demonstração <ArrowRight size={18}/></a></div>
          <div className="sales-proof-row"><span><Check/>Sem cartão no teste</span><span><Check/>Ativação acompanhada</span><span><ShieldCheck/>Contato comercial protegido</span></div>
        </div>
        <div className="sales-hero-visual-v43 sales-hero-visual-v44"><img src="/assets/marketing/storefront-preview.webp" alt="Prévia do cardápio FoodWeb" loading="eager"/><div className="sales-hero-visual-badge"><strong>Experiência pronta para celular</strong><span>Cardápio, carrinho e checkout</span></div></div>
      </div></section>

      <section className="sales-trust-strip-v44"><div className="sales-shell"><div><ShoppingBag/><span><strong>Loja online em minutos</strong><small>Cardápio pronto para vender</small></span></div><div><BarChart3/><span><strong>Gestão em tempo real</strong><small>Pedidos e desempenho</small></span></div><div><Wallet/><span><strong>Financeiro gerencial</strong><small>Entradas, saídas e documentos</small></span></div><div><LockKeyhole/><span><strong>Segurança por padrão</strong><small>Turnstile nas ações públicas</small></span></div></div></section>

      <section id="recursos" className="sales-benefits sales-benefits-v43"><div className="sales-shell"><div className="sales-section-heading center"><span>POR QUE FOODWEB?</span><h2>Uma experiência melhor para quem compra e mais controle para quem administra.</h2></div><div className="sales-benefit-grid sales-benefit-grid-v43"><article><span><ShoppingBag/></span><h3>Cardápio que dá vontade de pedir</h3><p>Fotos em destaque, busca, categorias, adicionais e carrinho pensado para celular.</p></article><article><span><BarChart3/></span><h3>Entenda o que realmente vende</h3><p>Analytics para acompanhar visualizações, conversão e comportamento de compra.</p></article><article><span><Wallet/></span><h3>Financeiro simples e útil</h3><p>Entradas, saídas, categorias, vencimentos e leitura local de boletos, cupons e documentos.</p></article><article><span><ShieldCheck/></span><h3>Suporte reservado ao lojista</h3><p>O canal de suporte da plataforma fica disponível apenas dentro das áreas autenticadas de Admin e Master.</p></article></div></div></section>

      <section id="demonstracao" className="sales-product-tour-v43"><div className="sales-shell"><div className="sales-section-heading center"><span>VEJA ANTES DE ASSINAR</span><h2>Conheça a experiência que acompanha a operação do negócio.</h2><p>Vitrine, pedidos, números comerciais, financeiro e cobrança em um fluxo único.</p></div><div className="sales-tour-grid-v43"><figure className="sales-tour-main-v43 sales-ops-preview-v45"><div className="sales-ops-window-v45"><header><span className="sales-ops-brand-v45"><ShoppingBag size={17}/>FoodWeb</span><strong>Visão geral da operação</strong><small>Hoje</small></header><div className="sales-ops-kpis-v45"><article><span>Pedidos hoje</span><strong>27</strong><small>+18% vs. ontem</small></article><article><span>Faturamento</span><strong>R$ 1.846</strong><small>Pedidos concluídos</small></article><article><span>Ticket médio</span><strong>R$ 68,37</strong><small>Operação do dia</small></article></div><div className="sales-ops-body-v45"><section><div className="sales-ops-section-title-v45"><strong>Pedidos recentes</strong><span>Tempo real</span></div><div className="sales-ops-order-v45"><i>1048</i><div><strong>2x Smash + bebida</strong><small>Delivery · PIX</small></div><b className="is-preparing">Preparando</b></div><div className="sales-ops-order-v45"><i>1047</i><div><strong>Combo família</strong><small>Retirada · Cartão</small></div><b className="is-ready">Pronto</b></div><div className="sales-ops-order-v45"><i>1046</i><div><strong>Açaí 500ml</strong><small>Delivery · PIX</small></div><b className="is-done">Concluído</b></div></section><aside><div className="sales-ops-section-title-v45"><strong>Financeiro</strong><Wallet size={16}/></div><div className="sales-ops-cash-v45"><span>Entradas</span><strong>R$ 1.846,00</strong></div><div className="sales-ops-cash-v45 expense"><span>Saídas</span><strong>R$ 612,40</strong></div><div className="sales-ops-result-v45"><span>Resultado</span><strong>R$ 1.233,60</strong></div></aside></div></div><figcaption><strong>Da venda à gestão diária</strong><span>Pedidos, indicadores e financeiro em uma visão que representa a operação real do lojista.</span></figcaption></figure><div className="sales-tour-side-v43"><article><span>01</span><div><h3>Loja e cardápio</h3><p>Uma vitrine moderna, rápida e com identidade do estabelecimento.</p></div></article><article><span>02</span><div><h3>Pedidos e checkout</h3><p>Pedido salvo no sistema antes de abrir o WhatsApp, com proteção anti-robô.</p></div></article><article><span>03</span><div><h3>Financeiro e mensalidade</h3><p>Gestão gerencial e PIX mensal com conferência pelo Admin Master.</p></div></article><a className="sales-cta-primary" href={demoHref}>Abrir demonstração real <ArrowRight size={18}/></a></div></div></div></section>

      <section id="lojas" className="sales-stores sales-stores-v43"><div className="sales-shell"><div className="sales-section-heading split"><div><span>NEGÓCIOS PUBLICADOS</span><h2>Veja lojas que já estão no FoodWeb.</h2></div><Store size={28}/></div>{view.stores.length?<div className="sales-store-grid">{view.stores.map((store)=><a key={store.id} className="sales-store-card" href={`/${encodeURIComponent(store.slug)}`}><div className="sales-store-cover" style={store.coverUrl?{backgroundImage:`url(${store.coverUrl})`}:undefined}></div><div className="sales-store-content"><img src={store.logoUrl||'/favicon-foodweb-v046.svg'} alt="" loading="lazy" decoding="async"/><div><h3>{store.name}</h3><p>{store.description}</p><span>{[store.city,store.state].filter(Boolean).join(' · ')||'Atendimento online'}</span></div></div><div className="sales-store-footer"><span>{store.deliveryEnabled?'Delivery':''}{store.deliveryEnabled&&store.pickupEnabled?' + ':''}{store.pickupEnabled?'Retirada':''}</span><strong>Ver cardápio <ArrowRight size={15}/></strong></div></a>)}</div>:<div className="sales-empty-stores"><Store size={30}/><h3>As lojas publicadas aparecerão aqui automaticamente.</h3></div>}</div></section>

      <section id="planos" className="sales-plans sales-plans-v43"><div className="sales-shell"><div className="sales-section-heading center"><span>PLANOS</span><h2>Comece com o necessário e evolua quando fizer sentido.</h2><p>Experimente o Profissional por {trialDays} dias antes de decidir como continuar.</p></div><div className="sales-plan-grid">{view.plans.filter((plan)=>plan.code!=='DEMO').map((plan)=>{const recommended=plan.code==='PROFESSIONAL';return <article key={plan.id} className={`sales-plan-card ${recommended?'recommended':''}`}>{recommended&&<span className="sales-plan-badge">Teste por {trialDays} dias</span>}<small>{plan.code==='ESSENTIAL'?'PARA COMEÇAR':plan.code==='STARTER'?'PARA CRESCER':'GESTÃO COMPLETA'}</small><h3>{plan.name}</h3><div className="sales-plan-price"><strong>{currency.format(plan.monthlyPrice)}</strong><span>/mês</span></div><ul>{plan.featureCodes.slice(0,8).map((feature)=><li key={feature}><Check size={15}/>{featureLabels[feature]||feature.replaceAll('_',' ')}</li>)}</ul>{recommended?<ProtectedContactButton className="sales-plan-trial-link" intent="trial"><MessageCircle size={16}/>Quero testar por {trialDays} dias</ProtectedContactButton>:<a href="/admin/login">Já sou lojista <ArrowRight size={15}/></a>}</article>})}</div><div className="sales-plan-note"><ShieldCheck size={17}/><span>O telefone comercial não fica exposto no HTML. O contato é liberado pelo servidor somente após a validação anti-robô.</span></div></div></section>

      <section className="sales-final-cta sales-final-cta-v43"><div className="sales-shell"><div><span>COMECE COM A EXPERIÊNCIA COMPLETA</span><h2>Teste o Profissional por {trialDays} dias no seu negócio.</h2><p>O canal comercial público é protegido. O suporte técnico permanece restrito aos lojistas autenticados.</p></div><ProtectedContactButton className="sales-cta-light" intent="trial"><MessageCircle size={18}/>Quero começar agora</ProtectedContactButton></div></section>
    </main>

    <footer className="sales-footer"><div className="sales-shell"><a className="sales-brand" href="/"><span className="foodweb-brand-mark">FW</span><strong>FoodWeb</strong></a><span>Cardápio, pedidos e gestão para negócios de alimentação.</span><a href="/admin/login">Área do lojista</a></div></footer>
  </div>;
}
