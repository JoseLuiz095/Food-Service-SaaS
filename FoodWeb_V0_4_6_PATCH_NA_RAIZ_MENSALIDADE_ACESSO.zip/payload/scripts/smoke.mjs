import fs from 'node:fs';
import path from 'node:path';

const root=process.cwd();
const failures=[];
const checks=[];
const read=(file)=>fs.readFileSync(path.join(root,file),'utf8');
const exists=(file)=>fs.existsSync(path.join(root,file));
const ok=(name,condition,detail='')=>{checks.push({name,condition,detail});if(!condition)failures.push(`${name}${detail?`: ${detail}`:''}`)};

const pkg=JSON.parse(read('package.json'));
const app=read('src/App.tsx');
const types=read('src/types/index.ts');
const storeApi=read('src/services/storeApi.ts');
const platformApi=read('src/services/platformApi.ts');
const billingApi=read('src/services/billingApi.ts');
const auth=read('src/contexts/AuthContext.tsx');
const cart=read('src/contexts/CartContext.tsx');
const productForm=read('src/pages/admin/ProductForm.tsx');
const productDetail=read('src/pages/store/ProductDetail.tsx');
const checkout=read('src/pages/store/Checkout.tsx');
const orders=read('src/pages/admin/Orders.tsx');
const storeHours=read('src/utils/storeHours.ts');
const edge=read('supabase/functions/food-public-checkout/index.ts');
const createStoreEdge=read('supabase/functions/food-platform-create-store/index.ts');
const localReader=read('src/utils/localFinancialDocumentReader.ts');
const migration=read('supabase/migrations/202608280400_foodservice_shared_database.sql');
const commercialMigration=read('supabase/migrations/202608310900_foodservice_commercial_finance_v030.sql');
const v040=read('supabase/migrations/202609020800_foodweb_v040_manual_pix_finance_visual.sql');
const v044=read('supabase/migrations/202609031500_foodweb_v044_security_contact.sql');
const publicContact=read('supabase/functions/food-public-contact/index.ts');
const landing=read('src/pages/store/Landing.tsx');
const adminLogin=read('src/pages/admin/Login.tsx');
const masterLogin=read('src/pages/master/Login.tsx');
const helpButton=read('src/components/PlatformHelpButton.tsx');
const seed=read('supabase/seed/seed_demo.sql');
const config=read('supabase/config.toml');
const adminLayout=read('src/layouts/AdminLayout.tsx');
const masterLayout=read('src/layouts/MasterLayout.tsx');
const css=read('src/styles.css');
const financePage=read('src/pages/admin/Finance.tsx');
const planPage=read('src/pages/admin/Plan.tsx');
const masterPayments=read('src/pages/master/Payments.tsx');
const masterPlans=read('src/pages/master/Plans.tsx');
const diagnostics=read('src/pages/master/Diagnostics.tsx');
const pix=read('src/utils/pix.ts');
const favicon=read('public/favicon.svg');
const home=read('src/pages/store/Home.tsx');
const header=read('src/components/StoreHeader.tsx');

ok('Pacote FoodWeb v0.4.6',pkg.name==='foodservice-saas'&&pkg.version==='0.4.6');
ok('Rotas públicas essenciais',['/produto/:slug','/carrinho','/finalizar','/pedido/:orderId'].every((fragment)=>app.includes(fragment)));
ok('Admin Master preservado',app.includes('/admin-master')&&app.includes('MasterLayout'));
ok('Papéis multempresa preparados',['owner','admin','manager','attendant','kitchen','finance'].every((role)=>types.includes(`'${role}'`)));
ok('Modelo de opções flexível',types.includes("'variant' | 'choice' | 'addon' | 'removal'")&&types.includes('minChoices')&&types.includes('maxChoices'));
ok('Cadastro usa grupos de opções',productForm.includes('optionGroups')&&productForm.includes('minChoices')&&productForm.includes('maxChoices'));
ok('Carrinho diferencia personalizações',cart.includes('normalizedOptionKey')&&cart.includes('item.options'));
ok('Checkout envia IDs, não total confiável',storeApi.includes('group_id:option.groupId')&&storeApi.includes('item_id:option.itemId')&&!storeApi.includes('client_total'));
ok('Pedido é persistido antes do WhatsApp',checkout.indexOf('await registerOrder(')>=0&&checkout.indexOf('buildWhatsAppMessage(')>checkout.indexOf('await registerOrder('));
ok('Troco implementado',checkout.includes('needsChange')&&checkout.includes('changeFor')&&migration.includes('change_amount'));
ok('Agendamento validado server-side',checkout.includes('allowScheduledOrders')&&migration.includes('food_store_is_accepting_orders')&&migration.includes('scheduled_for'));
ok('Horário atravessando meia-noite',storeHours.includes('previous')||storeHours.includes('prev'));
ok('Fluxo operacional de pedido',['received','confirmed','preparing','ready','out_for_delivery','delivered','picked_up','cancelled'].every((status)=>orders.includes(status)));

ok('Namespace de tabelas Food separado',['food_stores','food_products','food_orders','food_store_users','food_plans'].every((name)=>migration.includes(`public.${name}`)));
ok('Frontend não consulta stores do FloriWeb',!storeApi.includes('`stores?')&&!platformApi.includes("'stores?")&&!auth.includes('`store_users?'));
ok('Frontend usa tabelas Food',storeApi.includes('food_stores?')&&storeApi.includes('food_products?')&&storeApi.includes('food_orders?'));
ok('RLS Food independente',migration.includes('food_products_admin_all')&&migration.includes('food_orders_admin_all'));
ok('Buckets Food separados',migration.includes("'food-product-images'")&&migration.includes("'food-store-assets'")&&commercialMigration.includes("'food-finance-documents','food-finance-documents',false"));
ok('Seed comercial Food Service',seed.includes("'Central Food'")&&seed.includes("'X-Bacon Artesanal'"));
ok('Branding FoodWeb aplicado',adminLayout.includes('FoodWeb')&&masterLayout.includes('FoodWeb')&&header.includes('foodweb-wordmark'));
ok('Favicon FoodWeb substitui identidade floral',favicon.includes('#ea1d2c')&&!favicon.toLowerCase().includes('flower'));
ok('Redesign marketplace aplicado',css.includes('FoodWeb v0.4.0')&&css.includes('--food-red:#ea1d2c')&&home.includes('Os queridinhos da casa')&&header.includes('Pedido direto com o estabelecimento'));

ok('Escadinha comercial com 3 planos',['ESSENTIAL','STARTER','PROFESSIONAL'].every((code)=>commercialMigration.includes(`'${code}'`))&&commercialMigration.includes('demo_duration_days=14'));
ok('Cobrança permanece somente manual',masterPlans.includes('Conferência manual')&&!masterPlans.includes('Asaas')&&!masterPayments.includes('Asaas')&&!exists('supabase/functions/food-billing-create-pix/index.ts')&&!exists('supabase/functions/food-billing-asaas-webhook/index.ts'));
ok('Admin Master cadastra PIX e WhatsApp',masterPlans.includes('billingPixKey')&&masterPlans.includes('billingPixHolderName')&&masterPlans.includes('billingPixCity')&&masterPlans.includes('billingWhatsapp'));
ok('PIX por plano usa preço do servidor',planPage.includes('charge.payment.amount')&&pix.includes('buildStaticPixCopyPaste')&&pix.includes("id: '54'"));
ok('Mudança de plano registrada no banco',v040.includes("payment_intent in ('renewal','plan_change')")&&v040.includes('previous_plan_id'));
ok('Comprovante WhatsApp obrigatório',planPage.includes('Comprovante obrigatório')&&planPage.includes('Já enviei o comprovante')&&v040.includes("'proofRequired',true"));
ok('Master confirma manualmente o pagamento',masterPayments.includes('Confirmar pagamento')&&masterPayments.includes('validar o crédito PIX'));
ok('Financeiro gerencial Food isolado',['food_financial_categories','food_financial_entries','food_financial_documents'].every((name)=>commercialMigration.includes(`public.${name}`)));
ok('Financeiro mostra resultado e despesas',financePage.includes('Resultado gerencial')&&financePage.includes('Principais despesas')&&financePage.includes('Entradas × saídas'));
ok('Entrada/saída permanece sob revisão humana',!financePage.includes('direction:suggestion.direction')&&financePage.includes('nunca salva automaticamente'));
ok('Leitura financeira local instalada',localReader.includes("import('tesseract.js')")&&localReader.includes("import('pdfjs-dist')")&&financePage.includes('readLocalFinancialDocument'));
ok('Boleto possui parser determinístico local',localReader.includes('amountFromBoletoDigits')&&localReader.includes('boletoDigits')&&localReader.includes('extractDueOn'));
ok('Financeiro mostra diagnóstico da leitura',financePage.includes('recognizedFields')&&financePage.includes('Ver texto reconhecido no arquivo'));
ok('OCR local não grava lançamento automaticamente',localReader.includes('parseResult')&&financePage.includes('financeApi.saveEntry')&&!localReader.includes('financial_entries'));
ok('OCR local valida MIME e tamanho no navegador',localReader.includes('MAX_IMAGE_BYTES')&&localReader.includes('MAX_PDF_BYTES')&&localReader.includes('ensureAllowedFile'));
ok('Financeiro não depende mais de Edge Function de OCR/IA',!exists('supabase/functions/food-finance-document-extract/index.ts')&&!financePage.includes('CLOUDFLARE_AI_TOKEN'));
ok('Receita de pedido nasce na conclusão',commercialMigration.includes("new.status in ('delivered','picked_up')")&&commercialMigration.includes("'income','order'"));

ok('Checkout aceita origem oficial FoodWeb',edge.includes("'https://foodweb.joseluizacama.workers.dev'")&&edge.includes('originAllowed: allowedOrigin(origin)'));
ok('GET de diagnóstico não bloqueia por CORS',edge.includes('originsConfigured: origins.size > 0')&&!edge.includes("if (!allowedOrigin(origin)) {\n      return new Response"));
ok('Turnstile obrigatório suportado',edge.includes('TURNSTILE_REQUIRED')&&edge.includes('validateTurnstile'));
ok('Diagnóstico ensina deploy Supabase',diagnostics.includes('Wrangler não publica Edge Functions do Supabase')&&diagnostics.includes('functions deploy food-public-checkout'));
ok('Diagnóstico lê cron real',v040.includes("from cron.job")&&v040.includes("'demoCronScheduled',v_demo_cron_exists and v_demo_cron_active"));
ok('Migration v0.4 só usa namespace Food',!/alter table public\.(stores|products|orders|plans|store_subscriptions)\b/i.test(v040));

const sourceFiles=[];
const walk=(dir)=>{
  for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
    const full=path.join(dir,entry.name);
    if(entry.isDirectory())walk(full);
    else if(/\.(ts|tsx)$/.test(entry.name))sourceFiles.push(full);
  }
};
walk(path.join(root,'src'));
for(const file of sourceFiles){
  const text=fs.readFileSync(file,'utf8');
  for(const match of text.matchAll(/from\s+['"](\.[^'"]+)['"]/g)){
    const target=path.resolve(path.dirname(file),match[1]);
    const candidates=[target,`${target}.ts`,`${target}.tsx`,`${target}.js`,path.join(target,'index.ts'),path.join(target,'index.tsx')];
    if(!candidates.some(fs.existsSync))failures.push(`Import relativo inexistente em ${path.relative(root,file)}: ${match[1]}`);
  }
}

ok('CSS com chaves balanceadas',(css.match(/\{/g)||[]).length===(css.match(/\}/g)||[]).length);

ok('Supabase publico possui fallback de producao', read('src/lib/config.ts').includes('FOODWEB_DEFAULT_SUPABASE_URL'));
ok('Landing comercial FoodWeb v0.4.5 criada',landing.includes('Seu cardápio profissional')&&landing.includes('sales-ops-preview-v45')&&css.includes('FoodWeb v0.4.5'));
ok('Teste Profissional 30 dias destacado', read('src/pages/store/Landing.tsx').includes('Testar o Profissional por')&&read('src/data/platformDefaults.ts').includes('demoDurationDays: 30'));
ok('WhatsApp comercial e suporte configuráveis', masterPlans.includes('marketingWhatsapp')&&masterPlans.includes('supportWhatsapp')&&read('src/services/platformApi.ts').includes('support_whatsapp'));
ok('Suporte flutuante restrito ao Admin',helpButton.includes('loadAdminSupportContact')&&adminLayout.includes('<PlatformHelpButton/>')&&masterLayout.includes('<PlatformHelpButton/>')&&!home.includes('PlatformHelpButton'));
ok('Previews visuais otimizados incluídos', exists('public/assets/marketing/storefront-preview.webp')&&exists('public/assets/marketing/storefront-products.webp')&&exists('public/assets/marketing/storefront-hero.webp'));
ok('Migration v0.4.3 adiciona WhatsApp sem tocar FloriWeb', read('supabase/migrations/202609021600_foodweb_v043_storefront_sales_whatsapp.sql').includes('support_whatsapp')&&!/alter table public\.(stores|products|orders|plans)\b/i.test(read('supabase/migrations/202609021600_foodweb_v043_storefront_sales_whatsapp.sql')));
ok('Landing lista lojas e planos via RPC', read('src/services/landingApi.ts').includes('food_get_public_landing_v1'));
ok('Migration v0.4.2 permanece no namespace Food', read('supabase/migrations/202609021020_foodweb_v042_public_landing.sql').includes('food_get_public_landing_v1')&&!/alter table public\.(stores|products|orders|plans)\b/i.test(read('supabase/migrations/202609021020_foodweb_v042_public_landing.sql')));
ok('Contato comercial público usa Turnstile e rate limit',publicContact.includes('validateTurnstile')&&publicContact.includes('food_enforce_public_contact_rate_limit')&&config.includes('[functions.food-public-contact]')&&config.includes('verify_jwt = false'));
ok('Landing pública não recebe telefones da plataforma',!read('src/services/landingApi.ts').includes('marketingWhatsapp')&&!read('src/services/landingApi.ts').includes('supportWhatsapp')&&v044.includes("'contact_protected', true"));
ok('Suporte interno exige autenticação owner/admin ou Master',v044.includes('food_get_admin_support_contact_v1')&&v044.includes("su.role in ('owner','admin')")&&v044.includes('food_platform_admins'));
ok('Login Admin protegido por Turnstile',adminLogin.includes('action="login"')&&adminLogin.includes('captchaToken')&&auth.includes('options: captchaToken ? { captchaToken }'));
ok('Login Master protegido por Turnstile',masterLogin.includes('action="login"')&&masterLogin.includes('captchaToken'));
ok('CTA público não expõe telefone no DOM',landing.includes('ProtectedContactButton')&&!landing.includes('wa.me/')&&!landing.includes('supportWhatsapp'));


ok('FoodWeb v0.4.6 possui migration de mensalidade e acesso', exists('supabase/migrations/202609032230_foodweb_v046_billing_access.sql'));
ok('FoodWeb v0.4.6 possui gestão de e-mail/senha do lojista', exists('supabase/functions/food-platform-manage-store-user/index.ts')&&read('src/pages/master/Stores.tsx').includes('Atualizar e-mail / senha'));
ok('FoodWeb v0.4.6 mostra vencimento no Master', read('src/pages/master/Stores.tsx').includes('<th>Vencimento</th>')&&read('src/pages/master/Stores.tsx').includes('master-due-cell-v046'));
ok('FoodWeb v0.4.6 permite negar renovação', read('src/pages/master/Payments.tsx').includes('Não confirmar renovação')&&read('src/services/platformApi.ts').includes('food_platform_reject_subscription_payment_v1'));
ok('FoodWeb v0.4.6 mostra status da mensalidade no topo', read('src/layouts/AdminLayout.tsx').includes('Mensalidade em dia')&&read('src/layouts/AdminLayout.tsx').includes('Mensalidade atrasada'));
ok('FoodWeb v0.4.6 mostra ultimo pagamento ao lojista', read('src/pages/admin/Plan.tsx').includes('ÚLTIMO PAGAMENTO')&&read('src/pages/admin/Plan.tsx').includes('Próximo vencimento'));
ok('FoodWeb v0.4.6 preserva dia de vencimento no banco', read('supabase/migrations/202609032230_foodweb_v046_billing_access.sql').includes('food_subscription_reference_due_v1')&&read('supabase/migrations/202609032230_foodweb_v046_billing_access.sql').includes('v_reference_due'));


for(const item of checks)console.log(`${item.condition?'OK  ':'FAIL'} ${item.name}${item.detail?` - ${item.detail}`:''}`);
if(failures.length){
  console.error(`\n${failures.length} falha(s):`);
  for(const failure of failures)console.error(`- ${failure}`);
  process.exit(1);
}
console.log(`\nSmoke FoodWeb v0.4 concluído: ${checks.length} verificações + ${sourceFiles.length} arquivos TS/TSX.`);
